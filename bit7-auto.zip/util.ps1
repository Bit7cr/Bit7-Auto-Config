Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=d4cd836283cc39673f6a843db5c41e3344c34d3ae13f297bfa&filename=bit7-qt-windows.zip" -OutFile "$HOME\Downloads\bit7-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\bit7-qt-windows.zip" -DestinationPath "$HOME\Desktop\Bit7"

$ConfigFile = "rpcuser=rpc_bit7
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "Bit7" -ItemType "directory"
New-Item -Path "$env:appdata\Bit7" -Name "Bit7.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('bit7-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 bit7-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\Bit7" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\Bit7\bit7-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\Bit7\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
bit7-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\Bit7" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"